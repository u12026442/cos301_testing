/**
 *
 * @param database
 * @param spaces {{createBuzzSpace}}
 * @returns {{get, post, render}}
 */
module.exports = function(database, spaces) {
    var express = require('express');
    /**
     * @type {{get, post, render}}
     */
    var router = express.Router();

    /****** Infrastructure Routing *****/

    //create space
    router.get('/createSpace', function(req, res, next) {
        res.render('./dynamic_views/createSpace', {"title":"Create Space"});
    });

    //Close space
    router.get('/closeSpace', function(req, res, next) {
    //Pass to page
      res.render('./dynamic_views/closeSpace');
    });

    //Show infrastructure page
    router.get('/infrastructure', function(req, res, next) {
        //Pass to page
        res.render('infrastructure', {modules: '','title':'Infrastructure integration'});
    });

    //Admin management
    router.get('/adminManagement', function(req, res, next) {
    //Pass to page
      res.render('./dynamic_views/adminManagement');
    });

    router.post('/submitCS',
        /**
         *
         * @param req {{body : {CSyear, CSmodule, CSname} }}
         * @param res
         * @param next
         */
        function(req, res, next){
        /*
        console.log("test ["+req.body.CSyear+"]");
        console.log("test ["+req.body.CSmodule+"]");
        console.log("test ["+req.body.CSname+"]");
        */
        var obj ={};

        var body = req.body;
        obj.academicYear=body.CSyear;
            obj.isOpen = true;
            obj.moduleID = body.CSmodule;
            obj.name = body.CSname;
            obj.adminUsers = [];

        var result = spaces.createBuzzSpace(obj);

        console.log("this is the result " + result);
        res.render('./dynamic_views/createSpace',{message: result});
    });

    router.post('/submitRS', function(req, res, next){
        //console.log("test ["+req.body.RSmodule+"]");
        //console.log("test ["+req.body.RSid+"]");
        var obj = {};
            obj.moduleID = req.body.subNotify;

        var result = spaces.closeBuzzSpace(obj);

        res.render('./dynamic_views/closeSpace',{message: result});
    });

    router.post('/submitAAM', function(req, res, next){
        //console.log("test ["+req.body.Aadmin+"]");
        //console.log("test ["+req.body.AAid+"]");
        var obj = {};
            obj.moduleID = req.body.Aadmin;
            obj.userID = req.body.AAid;

        var result = spaces.assignAdministrator(obj);

        /*This should not use render, you want to send json data back
        * I think the correct function is send
        */
        res.render('./dynamic_views/adminManagement',{message: result});
    });

    router.post('/submitRAM', function(req, res, next){
        //console.log("test ["+req.body.Radmin+"]");
        //console.log("test ["+req.body.AAid+"]");
        var obj = {};
            obj.moduleID = req.body.Radmin;
            obj.userID = req.body.RAid;

        var result = spaces.removeAdministrator (obj);
        res.render('./dynamic_views/adminManagement',{message: result});
    });

router.get('/registerUser', function(req, res, next) {
//Pass to page
  res.render('./dynamic_views/registerUser');
});

router.post('/submitRU', function(req, res, next){
	/*
	console.log("test ["+req.body.RUuserName+"]");
	console.log("test ["+req.body.RUsignature+"]");
	console.log("test ["+req.body.RUuserid+"]");
	console.log("test ["+req.body.RUmoduleid+"]");
	*/
	var obj ={};
		obj.userNameForBuzzSpace=req.body.RUuserName;
		obj.signature=req.body.RUsignature;
		obj.userID=req.body.RUuserid;
		obj.moduleID=req.body.RUmoduleid;
		
	var result = spaces.createBuzzSpace(obj);
	
	//console.log("this is the result " + result);
	res.render('./dynamic_views/registerUser',{message: result});
});



    return  router;
};

exports['@literal'] = false;
exports['@require'] = ['buzz-database', 'buzz-spaces'];
