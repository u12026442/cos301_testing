node ./bin/www
